def do_twice(f, arg1, arg2):
    f(arg1, arg2)
    f(arg1, arg2)

'''def do_four(f, arg):
    do_twice(f, arg)
    do_twice(f, arg)
'''